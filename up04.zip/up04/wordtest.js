// 引入相关的库
var PizZip = require('pizzip');
var Docxtemplater = require('docxtemplater');
var fs = require('fs');
var path = require('path');
// 读取文件,以二进制文件形式保存
var content = fs.readFileSync(path.resolve(__dirname, 'exam.docx'), 'binary');
// 压缩数据
var zip = new PizZip(content);
// 生成模板文档
var doc =new Docxtemplater(zip);
// 设置填充数据
doc.setData({
    nsrmc: 'John',
    fr: 'Doe',
    sxh: '0652455478',
    dz: '重庆市江津区鼎山大道226'
});
//渲染数据生成文档
doc.render()
// 将文档转换文nodejs能使用的buf
var buf = doc.getZip().generate({ type: 'nodebuffer' });
// 输出文件
fs.writeFileSync(path.resolve(__dirname, 'output.docx'), buf);

//下面是处理EXCEL
// 引入模块
const xlsx = require('node-xlsx');

// 读取excel文件
const workSheetsFromBuffer = xlsx.parse(fs.readFileSync(`${__dirname}/data.xlsx`));


// 打印数据到控制台
console.log(workSheetsFromBuffer);

// 将数据保存到数组中
const data = [];
for (const workSheet of workSheetsFromBuffer) {
  for (const row of workSheet.data) {
    data.push(row);
    console.log("------"+row[0]+"===="+row[2]);
    row[3]="Done";
  }
}

// 打印数据到控制台
console.log(data);
const buffer = xlsx.build([{ name: "jsliang", data: data }]); // 拿到文件 buffer

  // 写入文件
fs.writeFileSync(path.join(__dirname, 'outexcel.xlsx'), Buffer.from(buffer));

