const puppeteer = require('puppeteer-core'); 
//如果上面的是只安装核心， 
//const puppeteer = require('puppeteer');

(async () => {
  //const browser = await puppeteer.launch({executablePath: 'D:\\chrome-win32\\chrome.exe',headless: false});
  const browser = await puppeteer.launch({executablePath: 'C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe',headless: false});
  const page = await browser.newPage();
  const timeout = 5000;
  page.setDefaultTimeout(timeout);


  {
      const targetPage = page;
      await targetPage.setViewport({
          width: 886,
          height: 624
      })
  }
  {
      const targetPage = page;
      const promises = [];
      const startWaitingForEvents = () => {
          promises.push(targetPage.waitForNavigation());
      }
      startWaitingForEvents();
      await targetPage.goto('https://tpass99.chongqing.chinatax.gov.cn:8443/#/login?redirect_uri=https%3A%2F%2Fetax99.chongqing.chinatax.gov.cn%3A5100%2Fmhzx%2Fapi%2Fmh%2Ftpass%2Fcode&client_id=z8b3h873z8z649h385a8f46eccfa5z4z&response_type=code&state=d1cb4db3ccc347dc8f7f93566b63ce99&client_pid=z8b3h873z8z649h385a8f46eccfa5z4z');
      await Promise.all(promises);
  }
  {
      const targetPage = page;
      await puppeteer.Locator.race([
          targetPage.locator('::-p-aria(统一社会信用代码/纳税人识别号)'),
          targetPage.locator('form > div:nth-of-type(1) input'),
          targetPage.locator('::-p-xpath(//*[@id=\\"app\\"]/div/div[1]/div[2]/div/div[2]/div[3]/div[2]/div/div[1]/div[1]/div/form/div[1]/div/div/div/div[1]/input)'),
          targetPage.locator(':scope >>> form > div:nth-of-type(1) input')
      ])
          .setTimeout(timeout)
          .click({
            offset: {
              x: 244,
              y: 14.3125,
            },
          });
  }
  {
      const targetPage = page;
      await puppeteer.Locator.race([
          targetPage.locator('::-p-aria(统一社会信用代码/纳税人识别号)'),
          targetPage.locator('form > div:nth-of-type(1) input'),
          targetPage.locator('::-p-xpath(//*[@id=\\"app\\"]/div/div[1]/div[2]/div/div[2]/div[3]/div[2]/div/div[1]/div[1]/div/form/div[1]/div/div/div/div/input)'),
          targetPage.locator(':scope >>> form > div:nth-of-type(1) input')
      ])
          .setTimeout(timeout)
          .fill('91500000450534616K');
  }
  {
      const targetPage = page;
      await puppeteer.Locator.race([
          targetPage.locator('::-p-aria(居民身份证号码/手机号码/用户名)'),
          targetPage.locator('form > div:nth-of-type(2) input'),
          targetPage.locator('::-p-xpath(//*[@id=\\"app\\"]/div/div[1]/div[2]/div/div[2]/div[3]/div[2]/div/div[1]/div[1]/div/form/div[2]/div/div/div/input)'),
          targetPage.locator(':scope >>> form > div:nth-of-type(2) input')
      ])
          .setTimeout(timeout)
          .click({
            offset: {
              x: 207,
              y: 29.3125,
            },
          });
  }
  {
      const targetPage = page;
      await puppeteer.Locator.race([
          targetPage.locator('::-p-aria(居民身份证号码/手机号码/用户名)'),
          targetPage.locator('form > div:nth-of-type(2) input'),
          targetPage.locator('::-p-xpath(//*[@id=\\"app\\"]/div/div[1]/div[2]/div/div[2]/div[3]/div[2]/div/div[1]/div[1]/div/form/div[2]/div/div/div/input)'),
          targetPage.locator(':scope >>> form > div:nth-of-type(2) input')
      ])
          .setTimeout(timeout)
          .fill('xdjcqcs');
  }
  {
      const targetPage = page;
      await puppeteer.Locator.race([
          targetPage.locator('::-p-aria(个人用户密码)'),
          targetPage.locator('form > div:nth-of-type(3) input'),
          targetPage.locator('::-p-xpath(//*[@id=\\"app\\"]/div/div[1]/div[2]/div/div[2]/div[3]/div[2]/div/div[1]/div[1]/div/form/div[3]/div[1]/div/div[2]/div/input)'),
          targetPage.locator(':scope >>> form > div:nth-of-type(3) input')
      ])
          .setTimeout(timeout)
          .click({
            offset: {
              x: 160,
              y: 25.3125,
            },
          });
  }
  {
      const targetPage = page;
      await targetPage.keyboard.down('CapsLock');
  }
  {
      const targetPage = page;
      await targetPage.keyboard.up('CapsLock');
  }
  {
      const targetPage = page;
      await puppeteer.Locator.race([
          targetPage.locator('::-p-aria(个人用户密码)'),
          targetPage.locator('form > div:nth-of-type(3) input'),
          targetPage.locator('::-p-xpath(//*[@id=\\"app\\"]/div/div[1]/div[2]/div/div[2]/div[3]/div[2]/div/div[1]/div[1]/div/form/div[3]/div[1]/div/div[2]/div/input)'),
          targetPage.locator(':scope >>> form > div:nth-of-type(3) input')
      ])
          .setTimeout(timeout)
          .fill('A');
  }
  {
      const targetPage = page;
      await targetPage.keyboard.down('CapsLock');
  }
  {
      const targetPage = page;
      await targetPage.keyboard.up('CapsLock');
  }
  {
      const targetPage = page;
      await puppeteer.Locator.race([
          targetPage.locator('::-p-aria(个人用户密码)'),
          targetPage.locator('form > div:nth-of-type(3) input'),
          targetPage.locator('::-p-xpath(//*[@id=\\"app\\"]/div/div[1]/div[2]/div/div[2]/div[3]/div[2]/div/div[1]/div[1]/div/form/div[3]/div[1]/div/div[2]/div/input)'),
          targetPage.locator(':scope >>> form > div:nth-of-type(3) input')
      ])
          .setTimeout(timeout)
          .fill('Abcd1234');
  }
  {
      const targetPage = page;
      await puppeteer.Locator.race([
          targetPage.locator('::-p-aria(登录)'),
          targetPage.locator('form button'),
          targetPage.locator('::-p-xpath(//*[@id=\\"app\\"]/div/div[1]/div[2]/div/div[2]/div[3]/div[2]/div/div[1]/div[1]/div/form/div[5]/div/button)'),
          targetPage.locator(':scope >>> form button')
      ])
          .setTimeout(timeout)
          .click({
            offset: {
              x: 163,
              y: 21.3125,
            },
          });
  }

  //await browser.close();

})().catch(err => {
  console.error(err);
  process.exit(1);
});
